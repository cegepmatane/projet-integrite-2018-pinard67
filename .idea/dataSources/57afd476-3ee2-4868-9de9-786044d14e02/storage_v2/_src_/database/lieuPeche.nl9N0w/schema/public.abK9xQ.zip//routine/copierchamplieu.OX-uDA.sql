create function copierchamplieu()
  returns void
language plpgsql
as $$
DECLARE 
	lieuCourante RECORD;
	totalLieu integer;
	moyenneHabitant integer;
	moyenneTaille double precision;
	checksum text;
BEGIN	
	checksum:='';
	FOR lieuCourante IN SELECT * from lieu
	LOOP
		SELECT MD5(string_agg(ville,'-'))  INTO checksum FROM lieu;
	END LOOP; 
	
	select count(*) INTO totalLieu from lieu;
	select AVG(habitant) INTO moyenneHabitant from lieu;
	select AVG(taille) INTO moyenneTaille from lieu;
	INSERT INTO statlieu (date, nombre_lieu, moyene_habitant, moyene_taille, checksum) VALUES ( NOW(), totalLieu ,moyenneHabitant, moyenneTaille, checksum);

END
$$;

alter function copierchamplieu()
  owner to postgres;

