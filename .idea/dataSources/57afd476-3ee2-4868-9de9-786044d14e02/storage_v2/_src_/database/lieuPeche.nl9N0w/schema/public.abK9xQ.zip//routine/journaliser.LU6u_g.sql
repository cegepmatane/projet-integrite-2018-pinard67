create function journaliser()
  returns trigger
language plpgsql
as $$
DECLARE
	avant_operation text;
	apres_operation text;
	operation text;
BEGIN

	IF TG_OP = 'UPDATE' THEN
		avant_operation:= '[ Ville : ' || OLD.ville || ' ]' || '[ Taille : ' || OLD.taille || ' ]' || '[ Habitants : ' || OLD.habitant || ' ]' || '[ EstCapitale : ' || OLD.estcapitale || ' ]';
		apres_operation:= '[ Ville : ' || NEW.ville || ' ]' || '[ Taille : ' || NEW.taille || ' ]' || '[ Habitants : ' || NEW.habitant || ' ]' || '[ EstCapitale : ' || NEW.estcapitale || ' ]';
		operation:= 'UPDATE';
	END IF;
	
	IF TG_OP = 'INSERT' THEN
		apres_operation:= '[ Ville : ' || NEW.ville || ' ]' || '[ Taille : ' || NEW.taille || ' ]' || '[ Habitants : ' || NEW.habitant || ' ]' || '[ EstCapitale : ' || NEW.estcapitale || ' ]';
		operation:= 'INSERT';
	END IF;
	
	IF TG_OP = 'DELETE' THEN
		avant_operation:= '[ Ville : ' || OLD.ville || ' ]' || '[ Taille : ' || OLD.taille || ' ]' || '[ Habitants : ' || OLD.habitant || ' ]' || '[ EstCapitale : ' || OLD.estcapitale || ' ]';
		operation:= 'DELETE';
	END IF;
	
	INSERT into journal(date, operation,objet,avant_operation,apres_operation) VALUES(NOW(), operation, 'lieu' ,avant_operation,apres_operation);
	
	IF TG_OP = 'DELETE' THEN
		return old;
	end if;
	
	RETURN new;
END

$$;

alter function journaliser()
  owner to postgres;

