create function journaliser()
  returns void
language plpgsql
as $$
BEGIN
INSERT into journal(date, operation,objet,avant_operation,apres_operation) VALUES(NOW(), 'ajouter','objet','poisson1','poisson2');
END
$$;

alter function journaliser()
  owner to postgres;

