create function journaliser()
  returns trigger
language plpgsql
as $$
DECLARE
	avant_operation text;
	apres_operation text;
	operation text;
BEGIN

	IF TG_OP = 'UPDATE' THEN
		avant_operation:= '[' || OLD.ville || ']';
		apres_operation:= '[' || NEW.ville || ']';
		operation:= 'UPDATE';
	END IF;
	
	IF TG_OP = 'INSERT' THEN
		apres_operation:= '[' || NEW.ville || ']';
		operation:= 'INSERT';
	END IF;
	
	IF TG_OP = 'DELETE' THEN
		avant_operation:= '[' || OLD.ville || ']';
		operation:= 'DELETE';
	END IF;
	
	INSERT into journal(date, operation,objet,avant_operation,apres_operation) VALUES(NOW(), operation, 'lieu' ,avant_operation,apres_operation);
	
	IF TG_OP = 'DELETE' THEN
		return old;
	end if;
	
	RETURN new;
END
$$;

alter function journaliser()
  owner to postgres;

