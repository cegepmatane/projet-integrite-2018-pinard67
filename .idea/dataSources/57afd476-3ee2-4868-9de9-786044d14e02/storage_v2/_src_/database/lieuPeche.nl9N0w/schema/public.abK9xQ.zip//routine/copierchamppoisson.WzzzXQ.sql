create function copierchamppoisson()
  returns void
language plpgsql
as $$
DECLARE 
	poissonCourant RECORD;
	totalPoisson integer;
	moyenneTaille double precision;
	moyennePoids double precision;
	checksum text;
BEGIN	
	checksum:='';
	FOR poissonCourant IN SELECT * from poisson
	LOOP
		SELECT MD5(string_agg(nom,'-'))  INTO checksum FROM poisson;
	END LOOP; 
	
	select count(*) INTO totalPoisson from poisson;
	select AVG(taille) INTO moyenneTaille from poisson;
	select AVG(poids) INTO moyennePoids from poisson;
	INSERT INTO statpoisson (date, nombre_poisson, moyene_taille, moyene_poids, checksum_nom) VALUES ( NOW(), totalPoisson ,moyenneTaille, moyennePoids, checksum);

END
$$;

alter function copierchamppoisson()
  owner to postgres;

